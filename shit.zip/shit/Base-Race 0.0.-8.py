'''
base race non-functional build
'''

# IMPORTS #
import pygame, math
from pygame.locals import *
# SETUPS #
pygame.init()

# screen size
screen = (1920,1080)

# sizing things
blockSize = 64
playerSize = 32 # unless pms = 1 playerSize has to be divisable by 16
pms = 2 # Player Move Speed
move = [0,0]

# client to server variables
gameStart = False
up = False
down = False
left = False
right = False
shoot = False
degree = 0

#COLORS#
BLUE = (0,170,255)
ORANGE = (255,170,0)
BEIGE = (255,240,200)
GREY = (170,170,170)
BLACK = (0,0,0)
WHITE = (255,255,255)
GREEN = (140,210,70)

# sets up client-server connection
#serverIp = input("Game Server IP: ")
#port = 25565 # I like building brown bricks with minecraft
# walkers coolio client stuff

# start window
win = pygame.display.set_mode(screen,pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.HWSURFACE)

# LEVEL FILE #
layout = open('BasicWorld.txt', 'r')

rectList = []

camPos = [0,0]

player = pygame.Rect((((screen[0] / 2) - (playerSize / 2)), ((screen[1] / 2) - (playerSize / 2)), playerSize, playerSize))

def buildWorld():
    row = 0
    col = 0
    world = layout.read().split('\n')
    for r in world:
        for c in r:
            if c != 'N':
                rectList.append(pygame.Rect((col), (row), blockSize, blockSize))
            col += blockSize
        row += blockSize
        col = 0

def drawBase():
    win.fill((255,255,255))
    for wall in rectList:
        wall.x += move[0]
        wall.y += move[1]
        pygame.draw.rect(win, (0,0,0), wall)
    if move[0] != 0:
        move[0] = 0
    if move[1] != 0:
        move[1] = 0
    pygame.draw.rect(win, (255,170,0), player)
    
    

# I FUCKING DID IT
def findCollisions():
    for wall in rectList:
        if player.right == wall.left and move[0] < 0 and (inRange(player.top, [wall.bottom, wall.top]) or inRange(player.bottom, [wall.bottom, wall.top])):
            move[0] = 0
        elif player.left == wall.right and move[0] > 0 and (inRange(player.top, [wall.bottom, wall.top]) or inRange(player.bottom, [wall.bottom, wall.top])):
            move[0] = 0
        if player.top == wall.bottom and move[1] > 0 and (inRange(player.left, [wall.right, wall.left]) or inRange(player.right, [wall.right, wall.left])):
            move[1] = 0
        elif player.bottom == wall.top and move[1] < 0 and (inRange(player.left, [wall.right, wall.left]) or inRange(player.right, [wall.right, wall.left])):
            move[1] = 0

def inRange(var, range):
    if var < range[0] and var > range[1]:
        return True
    else:
        return False

def main():
    buildWorld()

    #FPS counter things
    pygame.font.init()
    
    fpsClockTicker = pygame.time.Clock()
    
    fpsFont = pygame.font.Font('desc.ttf', 50)
    
    # IMPORTANT MAIN LOOP #
    while True:
        fpsClockTicker.tick()
        for event in pygame.event.get():
            # events go here
            if event.type == pygame.QUIT:
                return
            
        # keystrokes go here
        key = pygame.key.get_pressed()
        # quit
        if key[pygame.K_ESCAPE]:
            return
        # WASD
        if key[pygame.K_w]:
            move[1] = pms
        if key[pygame.K_a]:
            move[0] = pms
        if key[pygame.K_s]:
            move[1] = -pms
        if key[pygame.K_d]:
            move[0] = -pms
        if key[pygame.K_w] and key[pygame.K_s]:
            move[1] = 0
        if key[pygame.K_a] and key[pygame.K_d]:
            move[0] = 0
        
        # mouse handler
        mouse = pygame.mouse.get_pressed()
        # shooting
        # tbd how data transfer is handled
        # END OF EVENT HANDLER #
        findCollisions()
        drawBase()


        fpsTxt = fpsFont.render(str(fpsClockTicker.get_fps()), 0, (255, 0, 0))
        win.blit(fpsTxt, [0, 0])
        pygame.display.flip()

main()
pygame.quit()